package com.capgemini.bean;

import java.util.List;

import com.capgemini.bean.Transaction;

public class Account {

	private String accountNo;
	private String accountType;
	private double balance;
	private String name;
	private String phoneNo;
	private String address;
	private List<Transaction> trans;

	public Account() {
		super();
		
	}

	public Account(String accountType, double balance, String name,
			String phoneNo, String address) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Transaction> getTrans() {
		return trans;
	}

	public void setTrans(List<Transaction> trans) {
		this.trans = trans;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType="
				+ accountType + ", balance=" + balance + ", name=" + name
				+ ", phoneNo=" + phoneNo + ", address=" + address + "]";
	}

}
