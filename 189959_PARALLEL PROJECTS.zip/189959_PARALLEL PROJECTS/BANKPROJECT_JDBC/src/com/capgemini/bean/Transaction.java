package com.capgemini.bean;

import java.sql.Timestamp;

public class Transaction {
	private int transId;
	private String account;
	private double transAmount;
	private String transType;
	private String transDescription;
		

	public Transaction() {
		super();
		transAmount = 0;
		transType = null;
		transDescription = null;

	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Transaction(double transAmount, String transType,
			String transDescription, String accountNo) {
		super();
		this.setAccount(accountNo);
		this.transAmount = transAmount;
		this.transType = transType;
		this.transDescription = transDescription;
	}

	
	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getTransDescription() {
		return transDescription;
	}

	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", account=" + account + ", transAmount=" + transAmount
				+ ", transType=" + transType + ", transDescription=" + transDescription + "]";
	}

}
