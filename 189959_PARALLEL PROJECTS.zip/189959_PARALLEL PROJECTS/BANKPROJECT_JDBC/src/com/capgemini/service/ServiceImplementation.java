package com.capgemini.service;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.AccountDao;
import com.capgemini.exception.AccountNotFoundException;
import com.capgemini.exception.InsufficientBalanceException;

public class ServiceImplementation implements ServiceInterface {

	AccountDao dao = new AccountDao();

	@Override
	public void CreateAccount(Account account) throws SQLException {
		try {
			account.setAccountNo(dao.createAccount(account));
		} catch (SQLException e) {
		throw e;
		}

	}

	@Override
	public void deposit(String accountNo, double amount) throws AccountNotFoundException, SQLException {
		Account account = dao.getAccount(accountNo);
		if (account == null)
			throw new AccountNotFoundException("Account not found............");
		else {
			dao.updateBalance(accountNo, account.getBalance() + amount);
			dao.addTransaction(new Transaction(amount, "cr", "deposit", accountNo));
		}

	}

	@Override
	public void withDraw(String accountNo, double amount)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException {
		Account account = dao.getAccount(accountNo);
		if (account == null)
			System.out.println("No accounts found................");
		else {
			if (account.getBalance() > amount) {
				dao.updateBalance(accountNo, account.getBalance() - amount);
				dao.addTransaction(new Transaction(amount, "DR", "Withdraw", accountNo));
			} else {
				throw new InsufficientBalanceException("Insufficient Balance..........");
			}
		}

	}

	@Override
	public void showBalance(String accountNo) throws AccountNotFoundException,SQLException {
		Account account;
		try {
			account = dao.getAccount(accountNo);
			if (account == null)
				throw new AccountNotFoundException("NO Accounts Found...");
			else {
				System.out.println(account.getBalance());
			}
		} catch (SQLException e) {
			throw e;
		}

	}

	@Override
	public void fundTransfer(String fromAccountNo, String toAccountNo, double amount)
			throws AccountNotFoundException, InsufficientBalanceException,SQLException {

		try {
			Account fromAccount = dao.getAccount(fromAccountNo);
			Account toAccount = dao.getAccount(toAccountNo);
			if (fromAccount == null)
				throw new AccountNotFoundException(fromAccountNo);
			if (toAccount == null)
				throw new AccountNotFoundException(toAccountNo);
			if (fromAccount.getBalance() < amount)
				throw new InsufficientBalanceException("Insufficient Balance..... Please Try Again.......");
			dao.updateBalance(fromAccountNo, fromAccount.getBalance() - amount);
			dao.addTransaction(new Transaction(amount, "DR", "Fund Transfer", fromAccountNo));
			dao.updateBalance(toAccountNo, toAccount.getBalance() + amount);
			dao.addTransaction(new Transaction(amount, "CR", "Fund Transfer", toAccountNo));
		} catch (SQLException e) {
			throw e;
		}

	}

	@Override
	public void showTransaction(String accountNo) throws AccountNotFoundException ,SQLException{
		Account account;
		try {
			account = dao.getAccount(accountNo);
			if (account == null)
				System.out.println("No accounts found...............");
			System.out.println(dao.getTransactions(accountNo));
		} catch (SQLException e) {
			throw e;
		}

	}
}
