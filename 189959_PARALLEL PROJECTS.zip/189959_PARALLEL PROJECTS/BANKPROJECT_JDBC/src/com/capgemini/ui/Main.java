package com.capgemini.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bean.Account;
import com.capgemini.exception.AccountNotFoundException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.service.ServiceImplementation;

public class Main {
	static Scanner scan = new Scanner(System.in);

	public static String getInput(String message) {
		System.out.println(message);
		String input = scan.next();
		return input;
	}

	public static Account getAccount() {
		Account account = new Account();
		account.setName(getInput("Enter Name"));
		account.setPhoneNo(getInput("Enter PhoneNo"));
		account.setAccountType(getInput("Enter AccountType"));
		account.setAddress(getInput("Enter Your Address"));
		account.setBalance(Double.parseDouble(getInput("Enter Initial Balance")));
		return account;
	}

	public static void main(String[] args) {
		ServiceImplementation service = new ServiceImplementation();
		// Scanner scan = new Scanner(System.in);
		int choice = 0;
		while (choice != 8) {
			System.out.println("Welcome to XYZ Bank");
			System.out.println("1- Create Account ");
			System.out.println("2- Deposit");
			System.out.println("3- Withdraw");
			System.out.println("4- Show Balance");
			System.out.println("5- Fund Transfer");
			System.out.println("6- Print Transactions");
			System.out.println("7- Exit");
			System.out.println("Enter a choice");
			choice = Integer.parseInt(scan.next());
			switch (choice) {
			case 1:

				try {
					Account a1 = getAccount();
					service.CreateAccount(a1);
					System.out.println("Account Created Successfully\n"+ "Name:" + a1.getName() 
					+ "\nAccount Number:"+ a1.getAccountNo() + "\nAccount Type:" + a1.getAccountType());
					
				} catch (SQLException e) {
					e.getStackTrace();
				}
				break;
			case 2:

				System.out.println("Enter Account Number: ");
				String Number = scan.next();
				System.out.println("Enter Amount to be Deposited: ");
				double amount;
				try {
					amount = Double.parseDouble(scan.next());
					service.deposit(Number, amount);
				}catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("please Try Again......");
				}
				catch (InputMismatchException e) {
					System.out.println("Input Mismatch");
				} 
				catch (Exception e) {
				System.out.println("Unable to Deposite");
				}
				
				break;

			case 3:
				String withAccNo = getInput("Enter Account Number");
				
				try {
					double withAmount = Double
							.parseDouble(getInput("Enter withraw amount"));
					service.withDraw(withAccNo, withAmount);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				
				} catch (InsufficientBalanceException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
				System.out.println("please Try Again...........");
				}
				catch (InputMismatchException e) {
					System.out.println("Input Mismatch");
				}
				catch(NumberFormatException e){
					System.out.println("Wrong Inputs");
				}
				catch (Exception e) {
					System.out.println("Unable to Withdraw");
					}
				break;
				
			case 4:

				String accNo = getInput("Enter Account Number");
				try {
					service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("Unable to show balance");
				}

				break;
			case 5:

				try {
					String fromAccountNo = getInput("Give From Account Number ");
					String toAccountNo = getInput("Give To Account Number ");
					double transferAmount = Double
							.parseDouble(getInput("Amount To be Transferred "));
					service.fundTransfer(fromAccountNo, toAccountNo,
							transferAmount);
				}
				 catch (AccountNotFoundException e) {
						System.out.println(e.getMessage());
					
					} catch (InsufficientBalanceException e) {
						System.out.println(e.getMessage());
					}
				catch (Exception e) {
					System.out.println("Unable to Transfer");
				}
				
				
				break;

			case 6:

				System.out
						.println("Give From Account Number to Print Transaction Report");
				String accT = scan.next(); 
				try {
					service.showTransaction(accT);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("Unable to print transactions");
				}
				
				break;
				
			case 7:
				System.out.println("*****Thank You*****");
				
			default:
				System.out.println("Enter valid choice");

			}

		}
		scan.close();
	}
}
