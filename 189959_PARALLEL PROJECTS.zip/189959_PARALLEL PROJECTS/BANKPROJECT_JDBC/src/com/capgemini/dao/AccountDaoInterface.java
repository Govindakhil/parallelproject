package com.capgemini.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;

public interface AccountDaoInterface {

	String createAccount(Account account) throws SQLException;

	void updateBalance(String accountNo, double balance) throws SQLException;

	void addTransaction(Transaction transaction) throws SQLException;

	List<Transaction> getTransactions(String accountNo) throws SQLException;

	Account getAccount(String accountNo) throws SQLException;

}
