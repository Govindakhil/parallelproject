package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.AccountJDBC;

public class AccountDao implements AccountDaoInterface {

	@Override
	public String createAccount(Account account) throws SQLException {
		AccountJDBC connectionFactory = AccountJDBC.getInstance();
		Connection conn = connectionFactory.getConnection();
		String strSQL = "INSERT INTO Account(Accountnumber,name,phoneNo,address,balance,accountType) values(ACCNUMBER.nextval,?,?,?,?,?)";
		PreparedStatement statement = null;
		String accNo = null;
		try {
			statement = conn.prepareStatement(strSQL, new String[] { "ACCOUNTNUMBER" });

			statement.setString(1, account.getName());
			statement.setString(2, account.getPhoneNo());
			statement.setString(3, account.getAddress());
			statement.setDouble(4, account.getBalance());
			statement.setString(5, account.getAccountType());
			if (statement.executeUpdate() > 0) {
				ResultSet rs = statement.getGeneratedKeys();
				while (rs.next())
					accNo = rs.getString(1);
			}

		} catch (SQLException e) {
			
			throw e;
		} finally {
			conn.close();
		}
		return accNo;

	}

	@Override
	public void updateBalance(String accountNo, double balance) throws SQLException {
		String strSql = "UPDATE ACCOUNT SET BALANCE=? WHERE ACCOUNTNUMBER=?";
		AccountJDBC connectionFactory = AccountJDBC.getInstance();
		Connection conn = connectionFactory.getConnection();
		PreparedStatement statement = null;
		try {
			statement = conn.prepareStatement(strSql);
			statement.setDouble(1, balance);
			statement.setLong(2, Long.parseLong(accountNo));
			if (statement.executeUpdate() > 0) {
				System.out.println("Balance Updated:" + balance);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			conn.close();
		}

	}

	@Override
	public void addTransaction(Transaction transaction) throws SQLException {
		AccountJDBC connectionFactory = AccountJDBC.getInstance();
		Connection conn = connectionFactory.getConnection();
		String strSQL = "INSERT INTO TRANSACTION VALUES(TRANSEQ.nextval,?,?,?,?,SYSTIMESTAMP)";
		PreparedStatement statement = null;
		try {
			statement = conn.prepareStatement(strSQL);
			statement.setString(1, transaction.getAccount());
			statement.setDouble(2, transaction.getTransAmount());
			statement.setString(3, transaction.getTransType());
			statement.setString(4, transaction.getTransDescription());
			if (statement.executeUpdate() > 0) {

			}

		} catch (SQLException e) {
			
			throw e;
		} finally {
			conn.close();
		}

	}

	@Override
	public List<Transaction> getTransactions(String accountNo) throws SQLException {
		List<Transaction> transactions = new ArrayList<>();
		AccountJDBC connectionFactory = AccountJDBC.getInstance();
		Connection conn = connectionFactory.getConnection();
		String strSQL = "select * from transaction where account = ?";
		PreparedStatement statement = null;
		try {
			statement = conn.prepareStatement(strSQL);
			statement.setString(1, accountNo);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Transaction trans = new Transaction();
				trans.setTransId(resultSet.getInt(1));
				trans.setAccount(resultSet.getString(2));
				trans.setTransAmount(resultSet.getDouble(3));
				trans.setTransType(resultSet.getString(4));
				trans.setTransDescription(resultSet.getString(5));
				transactions.add(trans);
			}

		} catch (SQLException e) {
			throw e;
		} finally {
			conn.close();
		}
		return transactions;
	}

	@Override
	public Account getAccount(String accountNo) throws SQLException {
		Account account = null;
		AccountJDBC connectionFactory = AccountJDBC.getInstance();
		Connection conn = connectionFactory.getConnection();
		try {
			Long.parseLong(accountNo);
		} catch (NumberFormatException e) {
			return null;
		}
		String strSQL = "select * from account where accountnumber = ?";
		PreparedStatement statement = null;
		try {
			statement = conn.prepareStatement(strSQL);
			statement.setString(1, accountNo);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				account = new Account();
				account.setAccountNo(resultSet.getString(1));
				account.setName(resultSet.getString(4));
				account.setPhoneNo(resultSet.getString(5));
				account.setAddress(resultSet.getString(6));
				account.setBalance(resultSet.getDouble(3));
				account.setAccountType(resultSet.getString(2));
			}

		} catch (SQLException e) {
		
			throw e;
		} finally {
			conn.close();
		}
		return account;
	}
}
