package com.jpa.service;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.exceptions.InsufficientBalanceException;

public interface BankingService {

	void createAccount(Account account);

	void deposit() throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw() throws InsufficientBalanceException, AccountNotFoundException;
	
   	void fundsTransfer() throws InsufficientBalanceException,AccountNotFoundException;
	
	 void query();

}
