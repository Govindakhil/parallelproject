package com.jpa.exceptions;

public class AccountMismatchException extends Exception{

	public AccountMismatchException(Integer accno1, Integer accno2, String string)
	{
		super(accno1+" "+accno2+" "+string);
		System.err.println(accno1+" "+accno2+" "+string);
	}

}
