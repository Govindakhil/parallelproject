package com.jpa.dao;

import java.sql.Date;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.exceptions.InsufficientBalanceException;

public interface DaoInterface {
	void createAccount(Account account);

	void deposit(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;
	
	void query();

}
