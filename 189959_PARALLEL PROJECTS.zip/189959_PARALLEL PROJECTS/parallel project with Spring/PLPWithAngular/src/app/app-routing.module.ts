import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './bank/create-account/create-account.component';

import { ShowAccountsComponent } from './bank/show-accounts/show-accounts.component';
import { OperationsComponent } from './bank/operations/operations.component';
import { DepositComponent } from './bank/deposit/deposit.component';
import { TransactionListComponent } from './bank/transaction-list/transaction-list.component';
import { WithdrawComponent } from './bank/withdraw/withdraw.component';
import { FundsTransferComponent } from './bank/funds-transfer/funds-transfer.component';
import { GetAccountComponent } from './bank/get-account/get-account.component';



const routes: Routes = [
  { path:"create",component:CreateAccountComponent},
  { path:"show",component:ShowAccountsComponent},
  { path:"showTrans",component:TransactionListComponent},
  { path:"action",component:OperationsComponent},
  { path:"deposit",component:DepositComponent},
  { path:"withdraw",component:WithdrawComponent},
  {path:"get",component:GetAccountComponent},
  {path:"transfer",component:FundsTransferComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
