import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import {Account} from '../Account';

@Component({
  selector: 'app-show-accounts',
  templateUrl: './show-accounts.component.html',
  styleUrls: ['./show-accounts.component.css']
})
export class ShowAccountsComponent implements OnInit {
accounts:Account[];

  constructor(private bankService:BankService) { 
    this.bankService.populateAccounts().subscribe(data => this.accounts = data, error => console.log(error));
  }

  ngOnInit() {
    this.bankService.getAccounts();
  }

}
