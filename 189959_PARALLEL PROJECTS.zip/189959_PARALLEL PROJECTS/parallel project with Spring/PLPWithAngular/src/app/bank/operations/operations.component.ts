import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';


@Component({
  selector: 'app-operations',
  templateUrl: './operations.component.html',
  styleUrls: ['./operations.component.css']
})
export class OperationsComponent implements OnInit {
  account: Account;
  constructor(private bankService: BankService) { }

  ngOnInit() {
  }
  get(value) {
  
    this.bankService.getDetails(value).subscribe(data => {
      this.account = data;
    });
    console.log(this.account);
  }
}
