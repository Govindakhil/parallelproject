import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';
import {Account} from '../Account';
@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  account: Account;
  constructor(private bankService: BankService, private router: Router) { }

  ngOnInit() {
  }
  withdraw(value) {
    this.bankService.withdraw(value).subscribe(data => {
      this.account = data;
    });
    console.log(this.account);
    this.router.navigate(["/show"]);
  };
}
