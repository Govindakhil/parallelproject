package com.capgemini.spring.service;

import java.util.List;

import com.capgemini.spring.beans.Account;
import com.capgemini.spring.beans.Transaction;
import com.capgemini.spring.exceptions.AccountMismatchException;
import com.capgemini.spring.exceptions.AccountNotFound;
import com.capgemini.spring.exceptions.InvalidAmountException;

public interface BankService {

	List<Account> createAcccount(Account account);

	List<Account> getAllAccounts();

	

	List<Account> deposit(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> withdraw(int accno, double amount) throws InvalidAmountException, AccountNotFound;

	List<Account> fundsTransfer(int accno1, int accno2, double amount) throws AccountMismatchException, InvalidAmountException, AccountNotFound;

	List<Transaction> getAllTransactions();

	double getInitialBalance(int accno) throws AccountNotFound;

	List<Transaction> getTransactionByAccno(int accno);

	Account getAccountByNo(int accno) throws AccountNotFound;

	
}
